<?
$arModuleVersion = array(
    "VERSION" => "3.0.0",
    "VERSION_DATE" => "2016-08-29 11:02:23"
);
