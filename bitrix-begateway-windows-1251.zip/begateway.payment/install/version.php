<?
$arModuleVersion = array(
    "VERSION" => "3.0.5",
    "VERSION_DATE" => "2017-12-08 11:48:15"
);
