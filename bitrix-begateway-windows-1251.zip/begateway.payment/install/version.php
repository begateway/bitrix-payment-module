<?
$arModuleVersion = array(
    "VERSION" => "3.0.1",
    "VERSION_DATE" => "2017-02-20 10:22:15"
);
