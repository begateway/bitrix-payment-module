<?
$arModuleVersion = array(
    "VERSION" => "4.0.0",
    "VERSION_DATE" => "2020-12-10 10:01:00"
);
