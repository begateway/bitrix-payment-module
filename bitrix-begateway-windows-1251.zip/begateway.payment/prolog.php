<?
define("ADMIN_MODULE_NAME", "begateway.payment");
?>
