<?

$arModuleVersion = array(
    "VERSION" => "2.2.3",
    "VERSION_DATE" => "2016-08-31 18:22:13"
);
