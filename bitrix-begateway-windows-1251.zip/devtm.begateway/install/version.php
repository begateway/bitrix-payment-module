<?

$arModuleVersion = array(
    "VERSION" => "2.2.0",
    "VERSION_DATE" => "2016-08-02 10:10:10"
);
