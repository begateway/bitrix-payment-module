<?

$arModuleVersion = array(
    "VERSION" => "2.2.1",
    "VERSION_DATE" => "2016-08-26 16:22:13"
);
