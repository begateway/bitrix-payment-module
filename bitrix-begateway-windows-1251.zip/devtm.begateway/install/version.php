<?

$arModuleVersion = array(
    "VERSION" => "2.0.0",
    "VERSION_DATE" => "2015-08-26 10:10:10"
);
