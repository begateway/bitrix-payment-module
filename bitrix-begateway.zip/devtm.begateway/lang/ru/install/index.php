<?
$MESS["DEVTM_BEGATEWAY_MODULE_NAME"] = "Модуль платёжной системы на платформе beGateway";
