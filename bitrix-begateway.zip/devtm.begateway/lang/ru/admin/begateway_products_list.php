<?
$MESS["DEVTM_BEGATEWAY_PS_NOT_FOUND"] = "ID платёжной системы не найден. Укажите его в настройках модуля.";
$MESS["DEVTM_BEGATEWAY_ORDERS_NOT_FOUND"] = "Товары не найдены";
$MESS["DEVTM_BEGATEWAY_NAV_TITLE"] = "Страницы";
$MESS["DEVTM_BEGATEWAY_COL_ID_MESSAGE"] = "Заказы";
$MESS["DEVTM_BEGATEWAY_COL_USER_ID_MESSAGE"] = "Пользователи";
$MESS["DEVTM_BEGATEWAY_COL_STATUS_ID_MESSAGE"] = "Статус заказа";
$MESS["DEVTM_BEGATEWAY_COL_DATE_INSERT_MESSAGE"] = "Дата создания";
$MESS["DEVTM_BEGATEWAY_CONTEXT_MENU_MESSAGE"] = "Просмотр";
$MESS["DEVTM_BEGATEWAY_TITLE"] = "Список товаров beGateway";
$MESS["DEVTM_BEGATEWAY_ORDER_TITLE"] = "Заказ № ";
$MESS["DEVTM_BEGATEWAY_AUTH_FORM_MESSAGE"] = "Для данных групп пользователей доступ закрыт";
