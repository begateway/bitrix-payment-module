<?
$MESS["DEVTM_BEGATEWAY_NOT_CORRECT_ID"] = "Неверно задан ID заказа";
$MESS["DEVTM_BEGATEWAY_PS_NOT_FOUND"] = "ID платёжной системы не найден. Укажите его в настройках модуля.";
$MESS["DEVTM_BEGATEWAY_ORDER_NOT_FOUND"] = "Заказ не найден";
$MESS["DEVTM_BEGATEWAY_TRANSINFO_NOT_FOUND"] = "Информация по транзакциям не найдена";
$MESS["DEVTM_BEGATEWAY_TAB_TITLE"] = "Транзакции";
$MESS["DEVTM_BEGATEWAY_TITLE_DESC"] = "Информация по транзакциям";
$MESS["DEVTM_BEGATEWAY_ORDER_ID_TITLE"] = "ID Заказа";
$MESS["DEVTM_BEGATEWAY_AMOUNT_TITLE"] = "Цена";
$MESS["DEVTM_BEGATEWAY_USER_TITLE"] = "Пользователь в системе битрикс";
$MESS["DEVTM_BEGATEWAY_TRANSACTION_TITLE"] = "Транзакции";
$MESS["DEVTM_BEGATEWAY_TYPE_TITLE"] = "Тип";
$MESS["DEVTM_BEGATEWAY_UID_TITLE"] = "UID";
$MESS["DEVTM_BEGATEWAY_REASON_DESC"] = "Возврат денег";
$MESS["DEVTM_BEGATEWAY_NOTIFY_DESC"] = "Указывайте цену без точки. Например для 543.43 указывается 54343";