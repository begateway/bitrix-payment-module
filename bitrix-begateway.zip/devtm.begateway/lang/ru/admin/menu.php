<?
$MESS["DEVTM_BEGATEWAY_MENU_MAIN"] = "Товары beGateway";
$MESS["DEVTM_BEGATEWAY_MENU_LIST"] = "Список товаров";