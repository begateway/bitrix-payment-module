<?
$MESS["DEVTM_PAYMENT_ACTION_TITLE"] = "Обработчик beGateway";
$MESS["DEVTM_PAYMENT_ACTION_DESC"] = "Обработчик на платформе beGateway";