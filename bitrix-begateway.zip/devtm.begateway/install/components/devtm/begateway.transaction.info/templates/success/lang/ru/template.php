<?
$MESS["DEVTM_BEGATEWAY_SUCCESS_TITLE"] = "ОПЛАТА ПРОШЛА УСПЕШНО";
$MESS["DEVTM_BEGATEWAY_SUCCESS_ORDER_DESC"] = "Описание:";
$MESS["DEVTM_BEGATEWAY_SUCCESS_AMOUNT"] = "Сумма:";
$MESS["DEVTM_BEGATEWAY_SUCCESS_UID"] = "UID транзакции:";
$MESS["DEVTM_BEGATEWAY_SUCCESS_AUTH_CODE"] = "Коде авторизации:";
$MESS["DEVTM_BEGATEWAY_SUCCESS_AUTH_NUMBER"] = "Номер авторизации в системе обслуживания банка:";
$MESS["DEVTM_BEGATEWAY_SUCCESS_BILLING_DESCRIPTOR"] = "Вы можете найти этот платёж в Вашей банковской выписке по идентификатору:";
