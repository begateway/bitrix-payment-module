<?
$MESS["DEVTM_BEGATEWAY_NO_TRANS_INFO"] = "Информация по транзакции не может быть получена";
$MESS["DEVTM_BEGATEWAY_NO_TOKEN_ACCESS"] = "Токен не пренадлежит данному пользователю";
$MESS["DEVTM_BEGATEWAY_WRONG_TOKEN_LONG"] = "Токен неверной длины";
$MESS["DEVTM_BEGATEWAY_FAIL_TOKEN_QUERY"] = "Ошибка получения информации по транзакции";
