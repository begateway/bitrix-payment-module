<?
$MESS["DEVTM_BEGATEWAY_COMP_NAME"] = "Получение информации по транзакции beGateway";
$MESS["DEVTM_BEGATEWAY_COMP_DESC"] = "Получение информации по транзакции beGateway";
$MESS["DEVTM_BEGATEWAY_DEVTM_SERVICE"] = "Компоненты devtm";