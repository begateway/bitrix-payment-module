<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/devtm.begateway/admin/begateway_products_list.php");
?>