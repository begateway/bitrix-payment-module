<?

$arModuleVersion = array(
    "VERSION" => "2.1.0",
    "VERSION_DATE" => "2016-05-03 10:10:10"
);
