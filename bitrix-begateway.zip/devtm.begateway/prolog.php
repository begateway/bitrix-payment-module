<?
define("ADMIN_MODULE_NAME", "devtm.begateway");
?>