<?
$arModuleVersion = array(
    "VERSION" => "3.0.2",
    "VERSION_DATE" => "2017-02-20 10:22:15"
);
