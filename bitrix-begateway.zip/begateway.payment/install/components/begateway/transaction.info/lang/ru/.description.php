<?
$MESS["COMPONENT_BEGATEWAY_NAME"] = "Информация по транзакции beGateway";
$MESS["COMPONENT_BEGATEWAY_DESC"] = "Получение информации по транзакции от платёжной системы на платформе beGateway";
$MESS ['SOP_NAME'] = "Процедура заказа";
