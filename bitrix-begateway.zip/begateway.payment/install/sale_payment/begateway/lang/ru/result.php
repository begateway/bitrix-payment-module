<?
$MESS["SALE_BEGATEWAY_STATUS_MESSAGE_UID"] = "Идентификатор оплаты в платёжной системе";
$MESS["SALE_BEGATEWAY_STATUS_MESSAGE_TIME"] = "Время оплаты в платёжной системе";
$MESS["SALE_BEGATEWAY_FAIL_TOKEN_QUERY"] = "Ошибка получения информации по транзакции";
$MESS["SALE_BEGATEWAY_WRONG_TRACKING_ID"] = "Неизвестный токен платежа";
