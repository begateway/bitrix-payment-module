<?
$MESS["SALE_BEGATEWAY_ORDER_ID"] = "Заказ";
$MESS["SALE_BEGATEWAY_GET_TOKEN_ERROR"] = "Ошибка получения идентификатора на оплату: ";
$MESS["SALE_BEGATEWAY_BUY_BUTTON"] = "Перейти к оплате";
$MESS["SALE_BEGATEWAY_MODULE_ERROR"] = "Ошибка загрузки модуля оплаты";
