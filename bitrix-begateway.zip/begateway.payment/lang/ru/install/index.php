<?
$MESS["MODULE_BEGATEWAY_NAME"] = "Модуль оплаты beGateway";
$MESS["MODULE_BEGATEWAY_DESCRIPTION"] = "Модуль оплаты для платёжных систем на платформе beGateway";
